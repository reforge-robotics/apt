#pragma once

#include <cstddef>
#include <deque>
#include <optional>

#include "reforge_core/joint_tracker/sample.hpp"
#include "reforge_core/joint_tracker/stream.hpp"

namespace reforge::joint_tracker {

class JointTracker;

/** Report the one-sample adapter buffering state for integration diagnostics. */
struct JointTrackerSampleAdapterStatus final {
    /** Desired samples appended by the caller [samples]. */
    std::size_t desired_samples_appended = 0;

    /** Command samples emitted to the caller [samples]. */
    std::size_t command_samples_emitted = 0;

    /** Unread committed reference samples inside the wrapped stream [samples]. */
    std::size_t pending_reference_samples = 0;

    /** Command samples ready locally but not yet emitted [samples]. */
    std::size_t buffered_command_samples = 0;

    /** Committed reference samples, including stream-added holds [samples]. */
    std::size_t committed_reference_samples = 0;

    /** Held desired samples committed by planner-underrun fallback [samples]. */
    std::size_t hold_samples_added = 0;

    /** Whether the desired stream has been marked complete. */
    bool finished = false;
};

/** Adapt a Joint Tracker stream to a nonblocking one-sample control loop. */
class JointTrackerSampleAdapter final {
public:
    /** Create an adapter over one tracker's stream.
     *
     * `readiness_samples` is the minimum unread reference lookahead required
     * before a non-finalized adapter emits another command sample. Use `1`
     * only when loop latency dominates. Larger values, typically near the
     * model impulse horizon, trade startup delay for commands closer to the
     * optimized windowed stream path.
     */
    explicit JointTrackerSampleAdapter(
        const JointTracker& tracker,
        std::size_t readiness_samples);

    /** Append one desired sample and return at most one command sample. */
    [[nodiscard]] std::optional<JointSample> PushDesiredSample(JointSample sample);

    /** Return at most one command sample without appending new desired input. */
    [[nodiscard]] std::optional<JointSample> PopCommandSample();

    /** Mark the desired stream complete so remaining buffered samples drain. */
    void Finish() noexcept;

    /** Return whether the desired stream has been marked complete. */
    [[nodiscard]] bool finished() const noexcept {
        return stream_.finished();
    }

    /** Return current adapter and wrapped-stream diagnostics. */
    [[nodiscard]] JointTrackerSampleAdapterStatus status() const noexcept;

private:
    void FillCommandQueue();

    JointTrackerStream stream_;
    std::deque<JointSample> command_queue_;
    std::size_t readiness_samples_ = 1;
    std::size_t desired_samples_appended_ = 0;
    std::size_t command_samples_emitted_ = 0;
};

}  // namespace reforge::joint_tracker
