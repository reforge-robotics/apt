# Reforge Joint Tracker C++ Driver-Loop Demo

This hardware-free demo shows where Reforge Joint Tracker belongs in a generic
C++ robot-control application:

```text
planner, playback, or teleoperation desired joint sample
  -> Reforge Joint Tracker
  -> robot driver joint command
```

Build from an installed `reforge-core-joint-tracker` SDK:

```bash
cmake -S . -B build
cmake --build build --parallel
./build/reforge_joint_tracker_driver_loop_demo
```

Successful output:

```text
Reforge Joint Tracker driver loop complete.
```

`main.cpp` covers the four release-1 Reforge call patterns:

- complete trajectory upload with `JointTracker::OptimizeTrajectory`
- known-trajectory streaming with `JointTrackerStream`
- online planner streaming with incremental `AppendReferenceSample`
- sample-by-sample control loops with `JointTrackerSampleAdapter`

For a calibrated robot integration, load the joint-controller model bundle
before creating streams:

```cpp
reforge::joint_tracker::JointTracker tracker(config);
tracker.LoadModels("/path/to/joint_tracker/model_bundle");
```

The demo keeps model loading out of the installed smoke test so it can prove
the SDK installation without robot-specific calibration artifacts.
