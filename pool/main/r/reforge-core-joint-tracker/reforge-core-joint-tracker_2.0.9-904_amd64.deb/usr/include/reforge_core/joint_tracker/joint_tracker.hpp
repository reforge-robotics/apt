#pragma once

#include <string>

#include "reforge_core/joint_tracker/config.hpp"
#include "reforge_core/joint_tracker/stream.hpp"
#include "reforge_core/joint_tracker/trajectory.hpp"

namespace reforge::joint_tracker {

/** Provide the release-1 STL-only Joint Tracker facade. */
class JointTracker final {
public:
    /** Construct a tracker with validation and pass-through behavior.
     *
     * Args:
     *     config: Runtime settings used to validate trajectory dimensions and
     *         sample timing.
     */
    explicit JointTracker(JointTrackerConfig config);

    /** Return the immutable tracker configuration. */
    [[nodiscard]] const JointTrackerConfig& config() const noexcept {
        return config_;
    }

    /** Record the model directory for later model-loading phases.
     *
     * Args:
     *     model_directory: Non-empty directory path.
     */
    void LoadModels(std::string model_directory);

    /** Return whether a model directory has been recorded. */
    [[nodiscard]] bool has_loaded_models() const noexcept {
        return has_loaded_models_;
    }

    /** Return the number of loaded joint-axis models. */
    [[nodiscard]] std::size_t loaded_model_count() const noexcept {
        return loaded_model_count_;
    }

    /** Return a validated pass-through copy of the reference trajectory. */
    [[nodiscard]] JointTrajectory OptimizeTrajectory(
        const JointTrajectory& reference) const;

    /** Create a pass-through online reference stream. */
    [[nodiscard]] JointTrackerStream CreateStream() const;

private:
    JointTrackerConfig config_;
    bool has_loaded_models_ = false;
    std::size_t loaded_model_count_ = 0;
};

}  // namespace reforge::joint_tracker
