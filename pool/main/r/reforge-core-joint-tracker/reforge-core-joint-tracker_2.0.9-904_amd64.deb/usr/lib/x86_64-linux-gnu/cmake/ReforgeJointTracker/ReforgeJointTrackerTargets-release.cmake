#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ReforgeJointTracker::joint_tracker" for configuration "Release"
set_property(TARGET ReforgeJointTracker::joint_tracker APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ReforgeJointTracker::joint_tracker PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_joint_tracker.a"
  )

list(APPEND _cmake_import_check_targets ReforgeJointTracker::joint_tracker )
list(APPEND _cmake_import_check_files_for_ReforgeJointTracker::joint_tracker "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libreforge_joint_tracker.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
