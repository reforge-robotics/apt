#pragma once

#include <vector>

namespace reforge::joint_tracker {

/** Store one joint command sample on the controller timeline. */
struct JointSample final {
    /** Joint positions [rad]. */
    std::vector<double> positions_rad;

    /** Optional joint velocities [rad/s]. Empty means unavailable. */
    std::vector<double> velocities_rad_s;

    /** Optional joint accelerations [rad/s^2]. Empty means unavailable. */
    std::vector<double> accelerations_rad_s2;

    /** Sample timestamp [s]. */
    double time_s = 0.0;
};

}  // namespace reforge::joint_tracker
