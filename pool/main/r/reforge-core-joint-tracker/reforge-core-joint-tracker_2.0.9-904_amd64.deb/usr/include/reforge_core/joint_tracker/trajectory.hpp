#pragma once

#include <cstddef>
#include <vector>

#include "reforge_core/joint_tracker/sample.hpp"

namespace reforge::joint_tracker {

/** Own one validated sample-major joint trajectory. */
class JointTrajectory final {
public:
    /** Construct an empty trajectory. */
    JointTrajectory() = default;

    /** Construct a trajectory from owned samples.
     *
     * Args:
     *     samples: Sample-major joint trajectory. Each sample must contain the
     *         same non-zero number of joint positions and finite timing.
     */
    explicit JointTrajectory(std::vector<JointSample> samples);

    /** Build a position-only trajectory on a uniform time grid.
     *
     * Args:
     *     positions: Sample-major joint positions [rad].
     *     sample_time_s: Positive uniform sample period [s].
     */
    [[nodiscard]] static JointTrajectory FromPositions(
        std::vector<std::vector<double>> positions, double sample_time_s);

    /** Return owned trajectory samples. */
    [[nodiscard]] const std::vector<JointSample>& samples() const noexcept {
        return samples_;
    }

    /** Return the number of samples. */
    [[nodiscard]] std::size_t sample_count() const noexcept {
        return samples_.size();
    }

    /** Return the number of joints, or 0 for an empty trajectory. */
    [[nodiscard]] std::size_t joint_count() const noexcept {
        return joint_count_;
    }

    /** Return whether the trajectory contains no samples. */
    [[nodiscard]] bool empty() const noexcept {
        return samples_.empty();
    }

private:
    std::vector<JointSample> samples_;
    std::size_t joint_count_ = 0;
};

}  // namespace reforge::joint_tracker
